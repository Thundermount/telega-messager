/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegaserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import Telega.Message;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Maxwell
 */
public class TelegaServer {

    /**
     * @param args the command line arguments
     */
    static ServerSocket ss;

    public static void main(String[] args) throws IOException {
        // set up the port of the server
        final int PORT = 8800;
        // here goes server logic
        ss = new ServerSocket(PORT);
        //connections = new List<Socket>();
        // wait for server to get connection
        connections = new ArrayList<Socket>();
        while (true) {
            try {
                Socket conn = ss.accept();
                System.out.println("New user connected.");
                connections.add(conn);
                MultiThreadConnection tr = new MultiThreadConnection(conn);
                tr.start();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }

    }
    static List<Socket> connections;

    public static class MultiThreadConnection extends Thread {

//        static
                Socket conn;

        public MultiThreadConnection(Socket connection) {
            conn = connection;
        }

        public void run() {

            while (true) {
                try {
                    ObjectInputStream oi = new ObjectInputStream(conn.getInputStream());
                    Message msg = (Message) oi.readObject();
                                      //
                    for (int i = 0; i < connections.size(); i++) {
                        try {
                            ObjectOutputStream oo = new ObjectOutputStream(connections.get(i).getOutputStream());
                            oo.writeObject(msg);
                        } catch (Exception ee) {
                            connections.remove(i);
                        }
                    }
                } catch (Exception e) {
                    connections.remove(conn);
                    Thread.currentThread().stop();
                }

            }

        }
    }

}
