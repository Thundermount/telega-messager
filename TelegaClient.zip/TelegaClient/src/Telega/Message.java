/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Telega;

import java.io.File;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.util.Base64;
import javax.swing.JOptionPane;

/**
 *
 * @author Maxwell
 */
public class Message implements Serializable {

    private final String Msg;
    private final String Username;
    private final String Date;
    private byte[] img;

    public Message(String message_text, String username, String message_date) {
        Msg = message_text;
        Username = username;
        Date = message_date;
    }

    public String getMsg() {
        return Msg;
    }

    public String getUsername() {
        return Username;
    }

    public String getDate() {
        return Date;
    }

    public String getImage(){
        try{
        return new String(Base64.getEncoder().encode(img), "UTF-8");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            return "";
        }
    }
    
    public void LoadImage(String url) {
        try {
            img = Files.readAllBytes(new File(url).toPath());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ошибка при загрузке изображения.\n" + e.getMessage());
        }
    }

}
